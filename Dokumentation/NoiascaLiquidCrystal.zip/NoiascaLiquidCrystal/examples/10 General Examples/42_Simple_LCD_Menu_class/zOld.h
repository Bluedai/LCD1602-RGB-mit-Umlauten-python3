
/*
void updateMenuAlt()                      // displays the Menu and marks the actual entry
{
  if (menuSystem.screen == 0) s0.show(menuSystem.line);             //MISSING: avoid hardcoded object
  if (menuSystem.screen == 1) s1.show(menuSystem.line);
  if (menuSystem.screen == 2) s2.show(menuSystem.line);
  if (menuSystem.screen == 3) s3.show(menuSystem.line);
}




*/
