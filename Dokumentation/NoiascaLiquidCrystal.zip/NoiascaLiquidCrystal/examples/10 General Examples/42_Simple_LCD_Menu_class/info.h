/*
 Level 0 - Level 1

  Features:
 
  +"start" an item
  +choose from several options
  +enter a value with up and down
  +replace "back" button with "exit" menu entry
  

const char *entry1[noOfEntries][maxOptions] {
  {"Option A", nullptr },                  // etwas direkt ausführen
  {"Option B", "On", "Off"},               // submenu with two entries
  {"Option C", "red", "green", "blue"},    // submenu with three entries
  {"Option D", nulltpr},                   // Number entry with up and down keys
  {"Option E", "slow", "medium", "fast"},
  {"Option F", "slow", "medium", "fast"},
  {"Option G", "slow", "medium", "fast"}
};

menuScreen   besteht aus mehreren 1..n menuLines, soll scrollen wenn mehr einträge als Zeilen)
menuLine     hat einen Text, hat einen cursor, hat einen Marker, tut etwas bei select (eine Funktion, ein anderer Screen...)






 
 */
